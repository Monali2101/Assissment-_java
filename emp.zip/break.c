#include<stdio.h>
int main(){
    int n = 0;
    int i = 0;
    int j = 0;
    int choice = 0;

    float marks[100][3];
    float total[100];
    float avg[100];
    char grade[100];

    do{
        printf("\n=========Student Grade System============\n");
        printf("1. Enter Student Records : \n");
        printf("2. Display Student Report : \n");
        printf("3. Exit : \n");
        printf("Enter your choice : ");
        scanf("%d",&choice);

        switch (choice)
        {
        case 1:
            printf("\nEnter Number of Student :");
            scanf("%d",&n);

            for(i=0; i<n; i++){
                printf("\n Enter marks of students %d : \n",i+1);
                total[i]=0;
                for(j=0; j<3; j++){
                    do{
                        printf("\n Subject %d :", j+1);
                        scanf("%f",&marks[i][j]);
                        if(marks[i][j]<0 || marks[i][i]>100){
                            printf("invalid marks! Enter marks between 0 and 100. \n");
                        }

                    }while(marks[i][j]<0 || marks[i][j]>100);
                    total[i] = total[i] + marks[i][j];
                }
                avg[i] = total[i]/3;
                if(avg[i]>=90){
                    grade[i]='A';
                }else if(avg[i]>=80){
                    grade[i]='B';
                }else if(avg[i]>=70){
                    grade[i]='C';
                }else if(avg[i]>=60){
                    grade[i]='D';
                }else {
                    grade[i]='f';
                }
            }
            printf("\n Student REcord Added Successfully\n");
        break;

        case 2:
            printf("\n ===========Student Report System============\n");
            printf("\n ============================================\n");
            printf("\n No.\tTotal\tAverage\tGrade\n");
            printf("===============================================\n");
            for(i=0;i<n;i++){
                printf("%d\t%.2f\t%.2f\t%c\n",i+1,total[i],avg[i],grade[i]);
            }
            printf("\n ============================================\n");
        break;

        case 3:
        printf("\nExiting Programm....\n");
        break;
        
        default:
         printf("\n ============================= TRY AGAIN =========================== ");
        break;
        }
    }
    while(choice !=3);

    return 0;
}