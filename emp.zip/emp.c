#include<stdio.h>
#include<string.h>
struct Employee{
    int empid;
    char name[20];
    float salary;
};
int main(){
    struct Employee emp[2];
   for(int i=0;i<2;i++){
    printf("Enter employee %d,name,salary: ",i+1);
    scanf("%d %s %f",&emp[i].empid,emp[i].name,&emp[i].salary);
   }
    printf("\n");
    printf("-----------------------Employee details-----------------\n");
    for(int i=0;i<2;i++){
    printf("Employee ID: %d\n",emp[i].empid);
    printf("Employee Name: %s\n",emp[i].name);
    printf("Employee Salary: %.2f\n",emp[i].salary);
    printf("=======================\n");

    }
}